word=$1
SCRIPTPATH=$(dirname "$0")
`pwd`/steps/get_train_ctm.sh data/train data/lang exp/tri1 task7/ctm
# echo $SCRIPTPATH

rm -rf task7/output
mkdir task7/output

cd $SCRIPTPATH
python find.py --word $word --path `pwd`/ctm
cd -
 