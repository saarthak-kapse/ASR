import os
from argparse import ArgumentParser
import wave, struct
import sox

parser = ArgumentParser()
parser.add_argument("--word")
parser.add_argument("--path")

args = parser.parse_args()

word = args.word
path = args.path
ctm_file = open(path+'/ctm',"r+")

wav_data_path = path[:-10]+'/corpus/data/wav'
output_dir_path = path[:-4]+'/output/'

i=0
for line in ctm_file:
	if line.split()[-1] == word:
		input_path = wav_data_path + '/' + line.split()[0].split('_')[0] + '/' + line.split()[0] + '.wav'

		if i<10:
			output_path = output_dir_path + 'word0' + str(i) + '.wav'
		else:
			output_path = output_dir_path + 'word' + str(i) + '.wav'
		i += 1

		tfm = sox.Transformer()
		tfm.trim(float(line.split()[2]), float(line.split()[2])+float(line.split()[3]))
		tfm.build(input_path,output_path)

