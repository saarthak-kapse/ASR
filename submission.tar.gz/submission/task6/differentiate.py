import os
from argparse import ArgumentParser

parser = ArgumentParser()
parser.add_argument("--path")
args = parser.parse_args()

directory_path = args.path
#directory_path/scoring_g/test_filt.txt

good_g_file = open(directory_path+"/scoring_g/test_filt.txt","a")
music_m_file = open(directory_path+"/scoring_m/test_filt.txt","a")
noise_n_file = open(directory_path+"/scoring_n/test_filt.txt","a")
verynoisy_l_file = open(directory_path+"/scoring_l/test_filt.txt","a")


with open(directory_path+"/scoring_g/test_filt.txt", "r") as f:
    lines = f.readlines()
with open(directory_path+"/scoring_g/test_filt.txt", "w") as f:
    for line in lines:
        if line.split()[0][-1] == "g":
            f.write(line)

with open(directory_path+"/scoring_m/test_filt.txt", "r") as f:
    lines = f.readlines()
with open(directory_path+"/scoring_m/test_filt.txt", "w") as f:
    for line in lines:
        if line.split()[0][-1] == "m":
            f.write(line)

with open(directory_path+"/scoring_n/test_filt.txt", "r") as f:
    lines = f.readlines()
with open(directory_path+"/scoring_n/test_filt.txt", "w") as f:
    for line in lines:
        if line.split()[0][-1] == "n":
            f.write(line)

with open(directory_path+"/scoring_l/test_filt.txt", "r") as f:
    lines = f.readlines()
with open(directory_path+"/scoring_l/test_filt.txt", "w") as f:
    for line in lines:
        if line.split()[0][-1] == "l":
            f.write(line)
