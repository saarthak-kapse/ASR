#!/bin/bash
# Copyright 2012  Johns Hopkins University (Author: Daniel Povey)
# Apache 2.0

# ./task6/score.sh --cmd "/home/saarthak/Documents/kaldi/egs/assgmt2/recipe/utils/run.pl" /home/saarthak/Documents/kaldi/egs/assgmt2/recipe/data/test /home/saarthak/Documents/kaldi/egs/assgmt2/recipe/exp/tri1/graph /home/saarthak/Documents/kaldi/egs/assgmt2/recipe/exp/tri1/decode_test

[ -f ./path.sh ] && . ./path.sh

# begin configuration section.
cmd=run.pl
stage=0
decode_mbr=true
word_ins_penalty=0.0
min_lmwt=7
max_lmwt=17
#end configuration section.

[ -f ./path.sh ] && . ./path.sh
. parse_options.sh || exit 1;

if [ $# -ne 3 ]; then
  echo "Usage: local/score.sh [--cmd (run.pl|queue.pl...)] <data-dir> <lang-dir|graph-dir> <decode-dir>"
  echo " Options:"
  echo "    --cmd (run.pl|queue.pl...)      # specify how to run the sub-processes."
  echo "    --stage (0|1|2)                 # start scoring script from part-way through."
  echo "    --decode_mbr (true/false)       # maximum bayes risk decoding (confusion network)."
  echo "    --min_lmwt <int>                # minumum LM-weight for lattice rescoring "
  echo "    --max_lmwt <int>                # maximum LM-weight for lattice rescoring "
  exit 1;
fi

data=$1
lang_or_graph=$2
dir=$3

symtab=$lang_or_graph/words.txt

for f in $symtab $dir/lat.1.gz $data/text; do
  [ ! -f $f ] && echo "score.sh: no such file $f" && exit 1;
done

mkdir -p $dir/scoring_g/log
mkdir -p $dir/scoring_m/log
mkdir -p $dir/scoring_n/lang_or_graph
mkdir -p $dir/scoring_l/log


mkdir -p $dir/scoring_g/wer
mkdir -p $dir/scoring_m/wer
mkdir -p $dir/scoring_n/wer
mkdir -p $dir/scoring_l/wer

cat $data/text | sed 's:<NOISE>::g' | sed 's:<SPOKEN_NOISE>::g' > $dir/scoring_g/test_filt.txt
cat $data/text | sed 's:<NOISE>::g' | sed 's:<SPOKEN_NOISE>::g' > $dir/scoring_m/test_filt.txt
cat $data/text | sed 's:<NOISE>::g' | sed 's:<SPOKEN_NOISE>::g' > $dir/scoring_n/test_filt.txt
cat $data/text | sed 's:<NOISE>::g' | sed 's:<SPOKEN_NOISE>::g' > $dir/scoring_l/test_filt.txt

SCRIPTPATH=$(dirname "$0")

cd $SCRIPTPATH
python differentiate.py --path `pwd`/../$dir
cd -

$cmd LMWT=$min_lmwt:$max_lmwt $dir/scoring_g/log/best_path.LMWT.log \
  lattice-scale --inv-acoustic-scale=LMWT "ark:gunzip -c $dir/lat.*.gz|" ark:- \| \
  lattice-add-penalty --word-ins-penalty=$word_ins_penalty ark:- ark:- \| \
  lattice-best-path --word-symbol-table=$symtab \
    ark:- ark,t:$dir/scoring_g/LMWT.tra || exit 1;

$cmd LMWT=$min_lmwt:$max_lmwt $dir/scoring_m/log/best_path.LMWT.log \
  lattice-scale --inv-acoustic-scale=LMWT "ark:gunzip -c $dir/lat.*.gz|" ark:- \| \
  lattice-add-penalty --word-ins-penalty=$word_ins_penalty ark:- ark:- \| \
  lattice-best-path --word-symbol-table=$symtab \
    ark:- ark,t:$dir/scoring_m/LMWT.tra || exit 1;

$cmd LMWT=$min_lmwt:$max_lmwt $dir/scoring_n/log/best_path.LMWT.log \
  lattice-scale --inv-acoustic-scale=LMWT "ark:gunzip -c $dir/lat.*.gz|" ark:- \| \
  lattice-add-penalty --word-ins-penalty=$word_ins_penalty ark:- ark:- \| \
  lattice-best-path --word-symbol-table=$symtab \
    ark:- ark,t:$dir/scoring_n/LMWT.tra || exit 1;

$cmd LMWT=$min_lmwt:$max_lmwt $dir/scoring_l/log/best_path.LMWT.log \
  lattice-scale --inv-acoustic-scale=LMWT "ark:gunzip -c $dir/lat.*.gz|" ark:- \| \
  lattice-add-penalty --word-ins-penalty=$word_ins_penalty ark:- ark:- \| \
  lattice-best-path --word-symbol-table=$symtab \
    ark:- ark,t:$dir/scoring_l/LMWT.tra || exit 1;


# Note: the double level of quoting for the sed command
$cmd LMWT=$min_lmwt:$max_lmwt $dir/scoring_g/log/score.LMWT.log \
   cat $dir/scoring_g/LMWT.tra \| \
    utils/int2sym.pl -f 2- $symtab \| sed 's:\<UNK\>::g' \| \
    compute-wer --text --mode=present \
     ark:$dir/scoring_g/test_filt.txt  ark,p:- ">&" $dir/scoring_g/wer/wer_LMWT || exit 1;

$cmd LMWT=$min_lmwt:$max_lmwt $dir/scoring_m/log/score.LMWT.log \
   cat $dir/scoring_m/LMWT.tra \| \
    utils/int2sym.pl -f 2- $symtab \| sed 's:\<UNK\>::g' \| \
    compute-wer --text --mode=present \
     ark:$dir/scoring_m/test_filt.txt  ark,p:- ">&" $dir/scoring_m/wer/wer_LMWT || exit 1;

$cmd LMWT=$min_lmwt:$max_lmwt $dir/scoring_n/log/score.LMWT.log \
   cat $dir/scoring_n/LMWT.tra \| \
    utils/int2sym.pl -f 2- $symtab \| sed 's:\<UNK\>::g' \| \
    compute-wer --text --mode=present \
     ark:$dir/scoring_n/test_filt.txt  ark,p:- ">&" $dir/scoring_n/wer/wer_LMWT || exit 1;

$cmd LMWT=$min_lmwt:$max_lmwt $dir/scoring_l/log/score.LMWT.log \
   cat $dir/scoring_l/LMWT.tra \| \
    utils/int2sym.pl -f 2- $symtab \| sed 's:\<UNK\>::g' \| \
    compute-wer --text --mode=present \
     ark:$dir/scoring_l/test_filt.txt  ark,p:- ">&" $dir/scoring_l/wer/wer_LMWT || exit 1;

cd $SCRIPTPATH
python merge.py --path `pwd`/../$dir
cd - 

exit 0;
