import os
from argparse import ArgumentParser

parser = ArgumentParser()
parser.add_argument("--path")
args = parser.parse_args()

directory_path = args.path

#directory_path/scoring_g/test_filt.txt

good_g_wer_dir = directory_path+"/scoring_g/wer"
music_m_wer_dir = directory_path+"/scoring_m/wer"
noise_n_wer_dir = directory_path+"/scoring_n/wer"
verynoisy_l_wer_dir = directory_path+"/scoring_l/wer"

min_ = 7
max_ = 17

for i in range(7,18):

	wer_total = open(directory_path+"/wer_"+str(i),"w+")
	wer_g = open(directory_path+"/scoring_g/wer/wer_"+str(i),"r+")
	wer_m = open(directory_path+"/scoring_m/wer/wer_"+str(i),"r+")
	wer_n = open(directory_path+"/scoring_n/wer/wer_"+str(i),"r+")
	wer_l = open(directory_path+"/scoring_l/wer/wer_"+str(i),"r+")

	data1 = wer_g.read()
	data2 = wer_m.read()
	data3 = wer_n.read()
	data4 = wer_l.read()

	wer_total.write(data1)
	wer_total.write(data4)
	wer_total.write(data2)
	wer_total.write(data3)
	wer_g.close()
	wer_m.close()
	wer_n.close()
	wer_l.close()
	wer_total.close()


wer_best = 1
wer_best_file = 7

for i in range(7,18):
	total = 0
	correct = 0
	wer_total = open(directory_path+"/wer_"+str(i),"r+")

	for line in wer_total:

		if 'WER' in line.split()[0]:
			total += float(line.split()[5][:-1])
			correct += float(line.split()[3])

	if correct/total <wer_best:
		wer_best = correct/total
		wer_best_file = i 

	wer_total.close()


wer_total_best = open(directory_path+"/wer_"+str(wer_best_file),"r+")
final_list = []

for line in wer_total_best:
	if 'WER' in line.split()[0]:
		final_list.append(line[:-1])

print('(g) ',final_list[0])
print('(l) ',final_list[1])
print('(m) ',final_list[2])
print('(n) ',final_list[3])




